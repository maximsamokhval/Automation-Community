# bsl-genpas
Исходники взяты из https://github.com/maximsamokhval/bsl-genpas.git

Установленное окружение:
 - OneScript : https://oscript.io/
 - vanessa-runner : https://github.com/vanessa-opensource/vanessa-runner
 - vanessa-add : https://github.com/vanessa-opensource/add
 - Allure2 : https://github.com/allure-framework/allure2/releases

 ## Настройка окружения
 - Настройка Allure: https://infostart.ru/1c/articles/1010127/#%D0%A3%D1%81%D1%82%D0%B0%D0%BD%D0%BE%D0%B2%D0%BA%D0%B0_Allure